
 
<?php $__env->startSection('admin'); ?>


<div class="card card-default">
        <div class="card-header card-header-border-bottom">
            <h2>Atualizar Perfil de Usuário</h2>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong> 
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>  
        <?php endif; ?>

        <div class="card-body">

            <form method="post" action="<?php echo e(route('profile.atualizar')); ?>" class="form-pill">
               <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleFormControlInput3">Nome do usuário</label>
                    <input type="text" name="nome" class="form-control" id="current_password" placeholder="Senha atual" value="<?php echo e($user['name']); ?>" required>

                </div>

                <div class="form-group">
                    <label for="exampleFormControlInput3">E-mail do usuário</label>
                    <input type="text" name="email" class="form-control" id="current_password" placeholder="Senha atual" value="<?php echo e($user['email']); ?>" required>

                </div>

                <div class="form-group">
                    <label for="exampleFormControlInput3">E-mail do usuário</label>
                    <input type="file" name="imagem" class="form-control" id="current_password" placeholder="Senha atual" value="<?php echo e($user['email']); ?>" required>

                </div>

                <div class="form-footer pt-4 pt-5 mt-4 border-top">
                    <button type="submit" class="btn btn-primary btn-default">Atualizar</button>
                    <button type="submit" class="btn btn-secondary btn-default">Cancel</button>
                </div>
                

            </form>
        </div>
    

    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel8\basic\resources\views/admin/atualizar_perfil/index.blade.php ENDPATH**/ ?>